package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class SolveResistance extends AppCompatActivity {
    public static final String VOLTAGE_VALUE = "com.example.ec327project.VOLTAGE";
    public static final String CURRENT_VALUE = "com.example.ec327project.CURRENT";
    public static final String RESISTANCE_VALUE = "com.example.ec327project.RESISTANCE";
    public static DecimalFormat df = new DecimalFormat("0.0000");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resistance_input);
    }

    /** Called when the user taps the voltage button */
    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);

        EditText voltage = (EditText) findViewById(R.id.voltage_Value);
        EditText current = (EditText) findViewById(R.id.current_Value);
        String voltage_string = voltage.getText().toString();
        String current_string = current.getText().toString();

        if (voltage_string == null || voltage_string.trim().equals(""))
        {
            Toast.makeText(getBaseContext(), "Please enter a voltage value!", Toast.LENGTH_LONG).show();
        }
        else if (current_string == null || current_string.trim().equals(""))
        {
            Toast.makeText(getBaseContext(), "Please enter a current value!", Toast.LENGTH_LONG).show();
        }
        else
            {
            Double voltage_Value = Double.parseDouble(voltage.getText().toString());
            Double current_Value = Double.parseDouble(current.getText().toString());

            if (current_Value == 0)
            {
                Toast.makeText(getBaseContext(), "Current value cannot be 0!", Toast.LENGTH_LONG).show();
            }
            else {
                Double resistance_Value = voltage_Value / current_Value;

                String current_display = String.valueOf(df.format(current_Value));
                String resistance_display = String.valueOf(df.format(resistance_Value));
                String voltage_display = String.valueOf(df.format(voltage_Value));

                intent.putExtra(RESISTANCE_VALUE, resistance_display);
                intent.putExtra(VOLTAGE_VALUE, voltage_display);
                intent.putExtra(CURRENT_VALUE, current_display);

                startActivity(intent);
            }
        }
    }
}