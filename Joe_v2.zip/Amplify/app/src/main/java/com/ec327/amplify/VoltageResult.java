package com.ec327.amplify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import static com.ec327.amplify.SolveVoltage.CURRENT_VALUE;
import static com.ec327.amplify.SolveVoltage.RESISTANCE_VALUE;
import static com.ec327.amplify.SolveVoltage.VOLTAGE_VALUE;

public class VoltageResult extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.voltage_result);

        Intent intent = getIntent();

        String voltage_Value = intent.getStringExtra(VOLTAGE_VALUE);
        TextView voltage = findViewById(R.id.voltage_value_result);
        voltage.setText(voltage_Value);

        String current_Value = intent.getStringExtra(CURRENT_VALUE);
        TextView current = findViewById(R.id.current_value_result);
        current.setText(current_Value);

        String resistance_Value = intent.getStringExtra(RESISTANCE_VALUE);
        TextView resistance = findViewById(R.id.resistance_value_result);
        resistance.setText(resistance_Value);
    }
}