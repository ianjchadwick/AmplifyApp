package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent intent = getIntent();

        //Displays the voltage value
        String voltage_Value = intent.getStringExtra(SolveResistance.VOLTAGE_VALUE);
        TextView voltage = findViewById(R.id.voltage_value_result);
        voltage.setText(voltage_Value);

        //Displays the current value
        String current_Value;
        /*checks to see if the Voltage is 0, if so set current to 0, because you cannot have current
        with no Voltage*/
        if (Double.parseDouble(voltage_Value) == 0) {
            current_Value = "0.0";
        }
        else {
            current_Value = intent.getStringExtra(SolveResistance.CURRENT_VALUE);
        }
        TextView current = findViewById(R.id.current_value_result);
        current.setText(current_Value);

        //Displays the resistance values
        String resistance_Value = intent.getStringExtra(SolveResistance.RESISTANCE_VALUE);
        TextView resistance = findViewById(R.id.resistance_value_result);
        resistance.setText(resistance_Value);
    }

    /** Called when the user taps the start over button */
    public void gotomainpage(View view) {
        // Goes back to the main page
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}