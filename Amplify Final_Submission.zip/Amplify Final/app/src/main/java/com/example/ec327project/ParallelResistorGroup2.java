package com.example.ec327project;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ParallelResistorGroup2 extends AppCompatActivity {
    public static final String PRG2_RESISTANCE = "res2";

    //sets up the resistor stack
    myStack myRes = new myStack();

    //Instantiate all the buttons, arrays and lists
    Button addResistor;
    Button removeResistor;
    EditText resistanceValue;
    ArrayList<String> addArray = new ArrayList<>();
    ListView show;

    //tracks the number of resistors
    int resistorNum = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parallel_resistor_group2);

        //Associate the views with the correct IDs
        resistanceValue = (EditText) findViewById(R.id.resistor_value);
        addResistor = (Button) findViewById(R.id.addResistor);
        removeResistor = (Button) findViewById(R.id.removeResistor);
        show = (ListView) findViewById(R.id.ListView);

        //On-click listener to add a resistor
        addResistor.setOnClickListener(v -> {
            String getInput = resistanceValue.getText().toString();

            if (getInput == null || getInput.trim().equals("")) {
                Toast.makeText(getBaseContext(), "Please enter a value!", Toast.LENGTH_LONG).show();
            } else {
                addArray.add("Resistor " + resistorNum + ": " + getInput);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(ParallelResistorGroup2.this, android.R.layout.simple_list_item_1, addArray){
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        // Get the Item from ListView
                        View view = super.getView(position, convertView, parent);

                        // Initialize a TextView for ListView each Item
                        TextView tv = (TextView) view.findViewById(android.R.id.text1);

                        // Set the text color, size and font of TextView (ListView Item)
                        tv.setTextColor(Color.parseColor("#22b455"));
                        tv.setTextSize(18);
                        Typeface face = getResources().getFont(R.font.russo_one);
                        tv.setTypeface(face);

                        // Generate ListView Item using TextView
                        return view;
                    }
                };;
                show.setAdapter(adapter);
                ((EditText) findViewById(R.id.resistor_value)).setText(" ");
                myRes.push(Double.parseDouble(getInput));
                resistorNum++;
            }
        });

        //On-Click listener to remove a resistor from the stack and from the display array
        removeResistor.setOnClickListener(v -> {

            //Checks to see if the array is empty and throws an error if it is
            if (addArray.size() == 0)
            {
                Toast.makeText(getBaseContext(), "Please enter a resistor first!", Toast.LENGTH_LONG).show();
            }

            //Otherwise remove the last element from the stack and the array
            else
            {
                addArray.remove(addArray.size() - 1);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(ParallelResistorGroup2.this, android.R.layout.simple_list_item_1, addArray){
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override

                    //Code to handle the listview color
                    public View getView(int position, View convertView, ViewGroup parent) {
                        // Get the Item from ListView
                        View view = super.getView(position, convertView, parent);

                        // Initialize a TextView for ListView each Item
                        TextView tv = (TextView) view.findViewById(android.R.id.text1);

                        // Set the text color, size and font of TextView (ListView Item)
                        tv.setTextColor(Color.parseColor("#22b455"));
                        tv.setTextSize(18);
                        Typeface face = getResources().getFont(R.font.russo_one);
                        tv.setTypeface(face);

                        // Generate ListView Item using TextView
                        return view;
                    }
                };
                show.setAdapter(adapter);

                //pop the last element off the stack
                myRes.pop();
                resistorNum--;
            }

        });
    }

    /** Called when the user taps the done button */
    public void gotoPRG1(View view) {

        // Calculates the equivalent resistance value
        double FINAL = myRes.equiv();
        Intent intent = new Intent(this, SolveVoltage.class);

        //pushes the equivalent resistor back up to the previous level
        intent.putExtra(ParallelResistorGroup2.PRG2_RESISTANCE, FINAL);
        setResult(RESULT_OK, intent);
        finish();
    }


}