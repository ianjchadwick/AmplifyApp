package com.example.ec327project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ParallelResistorGroup2 extends AppCompatActivity {
    public static final String PRG2_RESISTANCE = "res2";
    myStack myRes = new myStack();

    Button addResistor;
    Button removeResistor;
    EditText resistanceValue;
    ArrayList<String> addArray = new ArrayList<>();
    ListView show;

    int resistorNum = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parallel_resistor_group2);

        resistanceValue = (EditText) findViewById(R.id.resistor_value);
        addResistor = (Button) findViewById(R.id.addResistor);
        removeResistor = (Button) findViewById(R.id.removeResistor);
        show = (ListView) findViewById(R.id.ListView);

        addResistor.setOnClickListener(v -> {
            String getInput = resistanceValue.getText().toString();

            if (getInput == null || getInput.trim().equals("")) {
                Toast.makeText(getBaseContext(), "Please enter a value!", Toast.LENGTH_LONG).show();
            } else {
                addArray.add("Resistor " + resistorNum + ": " + getInput);
                ArrayAdapter<String> adapter = new ArrayAdapter<>(ParallelResistorGroup2.this, android.R.layout.simple_list_item_1, addArray);
                show.setAdapter(adapter);
                ((EditText) findViewById(R.id.resistor_value)).setText(" ");
                myRes.push(Double.parseDouble(getInput));
                resistorNum++;
            }
        });

        removeResistor.setOnClickListener(v -> {
            if (addArray.size() == 0)
            {
                Toast.makeText(getBaseContext(), "Please enter a resistor first!", Toast.LENGTH_LONG).show();
            }
            else
            {
                addArray.remove(addArray.size() - 1);
                ArrayAdapter<String> adapter = new ArrayAdapter<>(ParallelResistorGroup2.this, android.R.layout.simple_list_item_1, addArray);
                show.setAdapter(adapter);
                myRes.pop();
                resistorNum--;
            }

        });
    }

    /** Called when the user taps the done button */
    public void gotoPRG1(View view) {
        // Do something in response to button
        double FINAL = myRes.equiv();
        Intent intent = new Intent(this, SolveVoltage.class);
        //newList = intent.getDoubleArrayExtra(SolveVoltage.CONTAINER);
        intent.putExtra(ParallelResistorGroup2.PRG2_RESISTANCE, FINAL);
        setResult(RESULT_OK, intent);
        //intent.putExtra(ParallelResistorGroup.newCONTAINER, newList);
        finish();
    }


}