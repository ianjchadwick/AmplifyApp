package com.example.ec327project;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SolveCurrent extends AppCompatActivity {
    public static final String VOLTAGE_VALUE = "com.example.ec327project.VOLTAGE";
    public static final String CURRENT_VALUE = "com.example.ec327project.CURRENT";
    public static final String RESISTANCE_VALUE = "com.example.ec327project.RESISTANCE";

    myStack myRes = new myStack();

    private static final int REQUEST_CODE = 0;

    Button addResistor;
    Button removeResistor1;
    EditText resistanceValue;
    ArrayList<String> addArray = new ArrayList<>();
    ListView show;

    int parallelResNum = 1;
    int resistorNum = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solve_current);
        //Intent i = getIntent();
        //String parallel_res_value = String.valueOf((i.getDoubleExtra(ParallelResistorGroup.RESISTANCE, 0)));
        //myRes.push(Double.parseDouble(test));
        //((TextView) findViewById(R.id.test)).setText(test);
        //if(test != "0.0"){
            //addArray.add(test);}

        resistanceValue = (EditText) findViewById(R.id.resistor_value);
        addResistor = (Button) findViewById(R.id.addResistorSeries);
        removeResistor1 = (Button) findViewById(R.id.removeResistor1);
        show = (ListView) findViewById(R.id.ListView);

        addResistor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getInput = resistanceValue.getText().toString();

                if (getInput == null || getInput.trim().equals("")) {
                    Toast.makeText(getBaseContext(), "Please enter a value!", Toast.LENGTH_LONG).show();
                } else {
                    addArray.add("Resistor " + resistorNum + ": " + getInput);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(SolveCurrent.this, android.R.layout.simple_list_item_1, addArray) {
                        @RequiresApi(api = Build.VERSION_CODES.O)
                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            // Get the Item from ListView
                            View view = super.getView(position, convertView, parent);

                            // Initialize a TextView for ListView each Item
                            TextView tv = (TextView) view.findViewById(android.R.id.text1);

                            // Set the text color, size and font of TextView (ListView Item)
                            tv.setTextColor(Color.parseColor("#22b455"));
                            tv.setTextSize(18);
                            Typeface face = getResources().getFont(R.font.russo_one);
                            tv.setTypeface(face);

                            // Generate ListView Item using TextView
                            return view;
                        }
                    };
                    show.setAdapter(adapter);
                    ((EditText) findViewById(R.id.resistor_value)).setText(" ");
                    myRes.push(Double.parseDouble(getInput));
                    resistorNum++;
                }}
        });

        removeResistor1.setOnClickListener(v -> {
            if (addArray.size() == 0)
            {
                Toast.makeText(getBaseContext(), "Please enter a resistor first!", Toast.LENGTH_LONG).show();
            }
            else
            {
                addArray.remove(addArray.size() - 1);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(SolveCurrent.this, android.R.layout.simple_list_item_1, addArray){
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        // Get the Item from ListView
                        View view = super.getView(position, convertView, parent);

                        // Initialize a TextView for ListView each Item
                        TextView tv = (TextView) view.findViewById(android.R.id.text1);

                        // Set the text color, size and font of TextView (ListView Item)
                        tv.setTextColor(Color.parseColor("#22b455"));
                        tv.setTextSize(18);
                        Typeface face = getResources().getFont(R.font.russo_one);
                        tv.setTypeface(face);

                        // Generate ListView Item using TextView
                        return view;
                    }
                };
                show.setAdapter(adapter);
                myRes.pop();
                resistorNum--;
            }

        });

    }


    public void addparallelgroup(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ParallelResistorGroup.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    // This method is called when the second activity finishes
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        // Check that it is the SecondActivity with an OK result
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK)
            {
                String parallel_res_value = String.valueOf((data.getDoubleExtra(ParallelResistorGroup.RESISTANCE, 0)));
                myRes.push(Double.parseDouble(parallel_res_value));
                //((TextView) findViewById(R.id.test)).setText(parallel_res_value);
                if(parallel_res_value != "0.0")
                {
                    addArray.add("Parallel Resistor Group " + parallelResNum + ": " + parallel_res_value);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(SolveCurrent.this, android.R.layout.simple_list_item_1, addArray){
                        @RequiresApi(api = Build.VERSION_CODES.O)
                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            // Get the Item from ListView
                            View view = super.getView(position, convertView, parent);

                            // Initialize a TextView for ListView each Item
                            TextView tv = (TextView) view.findViewById(android.R.id.text1);

                            // Set the text color, size and font of TextView (ListView Item)
                            tv.setTextColor(Color.parseColor("#22b455"));
                            tv.setTextSize(18);
                            Typeface face = getResources().getFont(R.font.russo_one);
                            tv.setTypeface(face);

                            // Generate ListView Item using TextView
                            return view;
                        }
                    };
                    show.setAdapter(adapter);
                    //((EditText) findViewById(R.id.resistor_value)).setText(" ");
                    //myRes.push(Double.parseDouble(parallel_res_value));
                    parallelResNum++;
                }
            }
        }
    }

    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);

        EditText voltage = (EditText) findViewById(R.id.voltage_Value_V);
        String voltage_display = voltage.getText().toString();

        if (voltage_display == null || voltage_display.trim().equals(""))
        {
            Toast.makeText(getBaseContext(), "Please enter a voltage value!", Toast.LENGTH_LONG).show();
        }
        else
            {
            double voltage_Value;
            double resistance_Value = myRes.sum();
            voltage_Value = Double.parseDouble(voltage_display);
                double current_Value = (voltage_Value / resistance_Value);

                String resistance_display = String.valueOf(resistance_Value);
                String current_display = String.valueOf(current_Value);

                intent.putExtra(RESISTANCE_VALUE, resistance_display);
                intent.putExtra(CURRENT_VALUE, current_display);
                intent.putExtra(VOLTAGE_VALUE, voltage_display);

                startActivity(intent);

            }
        }
}
