package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SolveVoltage extends AppCompatActivity {
    public static final String VOLTAGE_VALUE = "com.example.ec327project.VOLTAGE";
    public static final String CURRENT_VALUE = "com.example.ec327project.CURRENT";
    public static final String RESISTANCE_VALUE = "com.example.ec327project.RESISTANCE";

    myStack myRes = new myStack();

    Button addResistor;
    EditText resistanceValue;
    ArrayList<String> addArray = new ArrayList<>();
    ListView show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solve_voltage);
        Intent i = getIntent();
        String test = String.valueOf((i.getDoubleExtra(ParallelResistorGroup.RESISTANCE, 0)));
        myRes.push(Double.parseDouble(test));
        ((TextView) findViewById(R.id.test)).setText(test);
        if(test != "0.0"){
            addArray.add(test);}

        resistanceValue = (EditText) findViewById(R.id.resistor_value);
        addResistor = (Button) findViewById(R.id.addResistorSeries);
        show = (ListView) findViewById(R.id.ListView);

        addResistor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getInput = resistanceValue.getText().toString();

                if (getInput == null || getInput.trim().equals("")) {
                    Toast.makeText(getBaseContext(), "Please enter a value!", Toast.LENGTH_LONG).show();
                } else {
                    addArray.add(getInput);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(SolveVoltage.this, android.R.layout.simple_list_item_1, addArray);
                    show.setAdapter(adapter);
                    ((EditText) findViewById(R.id.resistor_value)).setText(" ");
                    myRes.push(Double.parseDouble(getInput));
                }}
        });}


    public void addSeries(){

    }


    public void addparallelgroup(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ParallelResistorGroup.class);
        startActivity(intent);
    }



    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);

        EditText current = (EditText) findViewById(R.id.current_Value_V);
        String current_display = current.getText().toString();
        double current_Value;
        double resistance_Value = myRes.sum();
        current_Value = Double.parseDouble(current_display);
        double voltage_Value = ((resistance_Value) * (current_Value));

        String resistance_display = String.valueOf(resistance_Value);
        String voltage_display = String.valueOf(voltage_Value);

        intent.putExtra(RESISTANCE_VALUE, resistance_display);
        intent.putExtra(CURRENT_VALUE, current_display);
        intent.putExtra(VOLTAGE_VALUE, voltage_display);

        startActivity(intent);
    }
}
