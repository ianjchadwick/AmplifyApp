package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.NumberFormat;

public class VoltageInputActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voltage_input);

        //newResistor = findViewById(R.id.textView13);
        //et = findViewById(R.id.resistor1_value);
        //ll = (LinearLayout)findViewById(R.id.linearLayout1);
    }

    /** Called when the user taps the voltage button */
    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String voltage = editText.getText().toString();
        //intent.putExtra(VOLTAGE_VALUE, voltage);
        startActivity(intent);

    }
    int resistorNum = 2;

    /** Called when the user taps the add resistor in series button */
    public void addresistorseries(View view) {
        // Do something in response to button

        //newResistor.setText("Resistor 2");

        LinearLayout ll1 = (LinearLayout)findViewById(R.id.linearLayout1);
        LinearLayout ll2 = (LinearLayout)findViewById(R.id.linearLayout2);
        LinearLayout ll3 = (LinearLayout)findViewById(R.id.linearLayout3);
        //TableLayout tb = (TableLayout)findViewById(R.id.tableLayout);
        TextView tv = new TextView(this);
        EditText et = new EditText(this);
        Spinner sp = new Spinner(this);
        tv.setText("Resistor 2:");
        tv.setTextSize(20);
        tv.setHeight(130);
        tv.setGravity(20);
        et.setHint("Enter Value");
        et.setTextSize(20);
        et.setHeight(160);
        et.setInputType(2);

        String resistorList[] = {"In Parallel to R1","In Series to R1"};
        ArrayAdapter resistorArray = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, resistorList);
        resistorArray.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        sp.setAdapter(resistorArray);
        sp.setMinimumHeight(0);
        ll1.addView(tv);
        ll2.addView(et);
        ll3.addView(sp);
        resistorNum++;
    }
}