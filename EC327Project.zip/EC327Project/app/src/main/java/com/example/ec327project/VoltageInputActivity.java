package com.example.ec327project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class VoltageInputActivity extends AppCompatActivity {

    private static final String current_Value = "current_Value";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voltage_input);

    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {

        //Something needs to happen here to save everything

        super.onSaveInstanceState(savedInstanceState);
    }

    //@Override
    //protected void onRestoreInstancesState(@NonNull Bundle savedInstanceState)
    /*
    if(savedInstanceState != null) {
        //Something happens here
    }
    */

    /**
     * Called when the user taps the solve button
     */
    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String voltage = editText.getText().toString();
        //intent.putExtra(VOLTAGE_VALUE, voltage);
        startActivity(intent);

    }

    int resistorNum = 2;
    //String resistorList[] = {"In Parallel to R1","In Series to R1"};
    //List<Integer> arrlist = new ArrayList<Integer>(Arrays.asList(arr));

    /**
     * Called when the user taps the add resistor in series button
     */
    public void addresistorseries(View view) {
        // Do something in response to button

        //newResistor.setText("Resistor 2");

        LinearLayout ll1 = (LinearLayout) findViewById(R.id.linearLayout1);
        LinearLayout ll2 = (LinearLayout) findViewById(R.id.linearLayout2);
        LinearLayout ll3 = (LinearLayout) findViewById(R.id.linearLayout3);

        TextView resistor_name = new TextView(this);
        EditText resistor_value = new EditText(this);
        Button delete = new Button(this);

        resistor_name.setText("Resistor " + Integer.toString(resistorNum) + ":");
        resistor_name.setTextSize(20);
        resistor_name.setHeight(130);
        resistor_name.setGravity(20);
        resistor_value.setHint("Enter Value");
        resistor_value.setTextSize(20);
        resistor_value.setHeight(160);
        resistor_value.setInputType(2);
        delete.setText("Delete");
        delete.setHeight(80);
        delete.setTextSize(12);

        ll1.addView(resistor_name);
        ll2.addView(resistor_value);
        ll3.addView(delete);
        resistorNum++;
        /** Code for creating a drop down list */
        //Spinner sp = new Spinner(this);
        //ArrayAdapter resistorArray = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, resistorList);
        //resistorArray.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        //sp.setAdapter(resistorArray);
        //sp.setMinimumHeight(0);

    }

    /**
     * Called when the user taps the add parallel resistor group button
     */
    public void addparallelgroup(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ParallelResistorInputActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String voltage = editText.getText().toString();
        //intent.putExtra(VOLTAGE_VALUE, voltage);
        startActivity(intent);

    }

}
