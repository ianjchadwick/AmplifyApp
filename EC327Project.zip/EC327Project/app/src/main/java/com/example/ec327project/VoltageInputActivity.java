package com.example.ec327project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModel;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class VoltageInputActivity extends AppCompatActivity {

    String current_Value = null;

    ArrayList<String> resistorList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voltage_input);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {

        //Something needs to happen here to save everything

        super.onSaveInstanceState(savedInstanceState);
    }

    //@Override
    //protected void onRestoreInstancesState(@NonNull Bundle savedInstanceState)
    /*
    if(savedInstanceState != null) {
        //Something happens here
    }
    */

    /**
     * Called when the user taps the solve button
     */
    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);
        startActivity(intent);

        EditText resistor = (EditText) findViewById(R.id.resistor1_value);
        String getInput = resistor.getText().toString();
        resistorList.add(getInput);

        EditText current = (EditText) findViewById(R.id.current_Value_V);
        getInput = current.getText().toString();
        current_Value = getInput;

        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(VoltageInputActivity.this, R.layout.activity_result, resistorList);
    }

    int resistorNum = 2;
    int resIDNum = 2;
    /**
     * Called when the user taps the add resistor in series button
     */
    public void addresistorseries(View view) {
        // Do something in response to button

        LinearLayout ll1 = (LinearLayout) findViewById(R.id.linearLayout1);
        LinearLayout ll2 = (LinearLayout) findViewById(R.id.linearLayout2);
        LinearLayout ll3 = (LinearLayout) findViewById(R.id.linearLayout3);

        /** Create a text box with resistor name: Resistor 2, 3 etc. */
        TextView resistor_name = new TextView(this);
        resistor_name.setText("Resistor " + Integer.toString(resistorNum) + ":");
        resistor_name.setTextSize(20);
        resistor_name.setHeight(130);
        resistor_name.setGravity(20);

        /** Create a user_input field and add the resistor to the array */
        EditText resistor_value = new EditText(this);
        resistor_value.setId(resIDNum);
        resistor_value.setHint("Enter Value");
        resistor_value.setTextSize(20);
        resistor_value.setHeight(160);
        resistor_value.setInputType(2);
        String getInput = resistor_value.getText().toString();
        resistorList.add(getInput);

        Button delete = new Button(this);
        delete.setText("Delete");
        delete.setHeight(80);
        delete.setTextSize(12);

        ll1.addView(resistor_name);
        ll2.addView(resistor_value);
        ll3.addView(delete);
        resistorNum++;
        resIDNum++;

        /** Code for creating a drop down list */
        //Spinner sp = new Spinner(this);
        //ArrayAdapter resistorArray = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, resistorList);
        //resistorArray.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        //sp.setAdapter(resistorArray);
        //sp.setMinimumHeight(0);

    }

    /**
     * Called when the user taps the add parallel resistor group button
     */
    public void addparallelgroup(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ParallelResistorInputActivity.class);
        startActivity(intent);
        //***NEED TO FIND OUT HOW TO SAVE DATA FROM THIS PAGE SO THAT WHEN YOU COM BACK FROM ADDING THE PARALLEL GROUP, EVERYTHING STAYS THE SAME

    }

}
