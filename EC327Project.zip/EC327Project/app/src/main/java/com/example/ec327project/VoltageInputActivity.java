package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class VoltageInputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voltage_input);
    }

    /** Called when the user taps the voltage button */
    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String voltage = editText.getText().toString();
        //intent.putExtra(VOLTAGE_VALUE, voltage);
        startActivity(intent);

    }
}