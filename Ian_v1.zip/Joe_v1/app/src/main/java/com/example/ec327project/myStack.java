package com.example.ec327project;

import java.util.Scanner;
import java.util.Vector;

public class myStack {
    Vector<Double> resVec;
    int size;

    // constructor sets size to 0 and creates an empty vector of resistor objects
    public myStack() {
        this.size = 0;
        Vector<Double> resVec = new Vector<Double>();
        this.resVec = resVec;
    }

    // Pushes newRes onto stack if the size is less than 25.
    public void push(double newRes) {
        this.resVec.add(newRes);
        this.size = this.size + 1;
    }

    public double equiv()
    {
        double sum = 0;
        int count = 0;
        double rEq;

        if (this.size == 1)
        {
            return this.resVec.get(0);
        }
        else
        {
            for (int i = 0; i < this.size; i++)
            {
                sum = sum + (1 / this.resVec.get(i));
                count++;
            }
        }

        rEq = (1 / sum);

        return rEq;
    }
}
