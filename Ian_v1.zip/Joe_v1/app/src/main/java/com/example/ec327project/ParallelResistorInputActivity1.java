package com.example.ec327project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Vector;

public class ParallelResistorInputActivity1 extends AppCompatActivity {
    public static final String RESISTANCE = "res";

    public class myStack {
        Vector<Double> resVec;
        int size;

        // constructor sets size to 0 and creates an empty vector of resistor objects
        public myStack() {
            this.size = 0;
            Vector<Double> resVec = new Vector<Double>();
            this.resVec = resVec;
        }

        // Pushes newRes onto stack if the size is less than 25.
        public void push(double newRes) {
            this.resVec.add(newRes);
            this.size = this.size + 1;
        }

        public double equiv()
        {
            double sum = 0;
            int count = 0;
            double rEq;

            if (this.size == 1)
            {
                return this.resVec.get(0);
            }
            else
            {
                for (int i = 0; i < this.size; i++)
                {
                    sum = sum + (1 / this.resVec.get(i));
                    count++;
                }
            }

            rEq = (1 / sum);

            return rEq;
        }
    }

    myStack myRes1 = new myStack();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parallel_resistor_input1);
    }

    /** Called when the user taps the done button */
    public void jumpto(View view) {
        // Do something in response to button
        double FINAL1 = myRes1.equiv();
        Intent intent = new Intent(this, ParallelResistorInputActivity.class);
        intent.putExtra(RESISTANCE, FINAL1);
        startActivity(intent);
        }

    int resistorNum = 2;

    /** Called when the user taps the add resistor button */
    public void addresistorseries(View view) {
        // Do something in response to button

        //newResistor.setText("Resistor 2");

        LinearLayout ll1 = (LinearLayout)findViewById(R.id.linearLayout1);
        LinearLayout ll2 = (LinearLayout)findViewById(R.id.linearLayout2);
        LinearLayout ll3 = (LinearLayout)findViewById(R.id.linearLayout3);

        TextView resistor_name = new TextView(this);
        EditText resistor_value = new EditText(this);
        Button delete = new Button(this);

        resistor_name.setText("Resistor " + Integer.toString(resistorNum) + ":");
        resistor_name.setTextSize(20);
        resistor_name.setHeight(130);
        resistor_name.setGravity(20);
        resistor_value.setHint("Enter Value");
        resistor_value.setTextSize(20);
        resistor_value.setHeight(160);
        resistor_value.setInputType(2);
        delete.setText("Delete");
        delete.setHeight(80);
        delete.setTextSize(12);

        ll1.addView(resistor_name);
        ll2.addView(resistor_value);
        ll3.addView(delete);
        resistorNum++;

        String newVal;
        double newValNum;

        newVal = resistor_value.getText().toString();
        if(!newVal.isEmpty())
        {
            newValNum = Double.parseDouble(newVal);
        }
        else
        {
            newValNum = 0;
        }

        myRes1.push(newValNum);

    }




}