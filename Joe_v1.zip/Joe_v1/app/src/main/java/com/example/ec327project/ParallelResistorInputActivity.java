package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Vector;

public class ParallelResistorInputActivity extends AppCompatActivity {
    public static final String RESISTANCE = "res";
    myStack myRes = new myStack();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parallel_resistor_input);

    }

    /** Called when the user taps the done button */
    public void gotovoltageinputpage(View view) {
        // Do something in response to button
        double FINAL = myRes.equiv();
        Intent intent = new Intent(this, VoltageInputActivity.class);
        intent.putExtra(RESISTANCE, FINAL);
        startActivity(intent);
        }

    int resistorNum = 2;


    /** Called when the user taps the add resistor button */
    public void addtogroup(View view) {
        // Do something in response to button

        //newResistor.setText("Resistor 2");

        LinearLayout ll1 = (LinearLayout)findViewById(R.id.linearLayout1);
        LinearLayout ll2 = (LinearLayout)findViewById(R.id.linearLayout2);
        LinearLayout ll3 = (LinearLayout)findViewById(R.id.linearLayout3);

        TextView resistor_name = new TextView(this);
        EditText resistor_value = new EditText(this);
        Button delete = new Button(this);

        resistor_name.setText("Resistor " + Integer.toString(resistorNum) + ":");
        resistor_name.setTextSize(20);
        resistor_name.setHeight(130);
        resistor_name.setGravity(20);
        resistor_value.setHint("Enter Value");
        resistor_value.setTextSize(20);
        resistor_value.setHeight(160);
        resistor_value.setInputType(2);
        delete.setText("Delete");
        delete.setHeight(80);
        delete.setTextSize(12);

        ll1.addView(resistor_name);
        ll2.addView(resistor_value);
        ll3.addView(delete);

        String newVal;
        double newValNum;

        newVal = resistor_value.getText().toString();
        if(!newVal.isEmpty())
            {
            newValNum = Double.parseDouble(newVal);
            }
        else
        {
            newValNum = 0;
        }

        myRes.push(newValNum);
    }

    public void addparallelgroup1(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ParallelResistorInputActivity1.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String voltage = editText.getText().toString();
        //intent.putExtra(VOLTAGE_VALUE, voltage);
        startActivity(intent);}


}

