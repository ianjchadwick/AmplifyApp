package com.example.ec327project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.text.DecimalFormat;

public class ResistanceInputActivity extends AppCompatActivity {
    public static final String VOLTAGE_VALUE = "com.example.ec327project.VOLTAGE";
    public static final String CURRENT_VALUE = "com.example.ec327project.CURRENT";
    public static final String RESISTANCE_VALUE = "com.example.ec327project.RESISTANCE";
    public static DecimalFormat df = new DecimalFormat("0.0000");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resistance_input);
    }

    /** Called when the user taps the voltage button */
    public void gotoresultpage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, ResultActivity.class);

        EditText voltage = (EditText) findViewById(R.id.voltage_Value);

        EditText current = (EditText) findViewById(R.id.current_Value);

        Double voltage_Value = Double.parseDouble(voltage.getText().toString());
        Double current_Value = Double.parseDouble(current.getText().toString());
        Double resistance_Value = voltage_Value/current_Value;

        String current_display = String.valueOf(df.format(current_Value));
        String resistance_display = String.valueOf(df.format(resistance_Value));
        String voltage_display = String.valueOf(df.format(voltage_Value));

        intent.putExtra(RESISTANCE_VALUE, resistance_display);
        intent.putExtra(VOLTAGE_VALUE, voltage_display);
        intent.putExtra(CURRENT_VALUE, current_display);

        startActivity(intent);
    }
}